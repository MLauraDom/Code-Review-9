-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 06, 2021 at 05:10 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cr9_famazon_lauramoldovan`
--
CREATE DATABASE IF NOT EXISTS `cr9_famazon_lauramoldovan` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `cr9_famazon_lauramoldovan`;

-- --------------------------------------------------------

--
-- Table structure for table `adress`
--

CREATE TABLE `adress` (
  `AdressID` int(11) NOT NULL,
  `Country` varchar(30) NOT NULL,
  `City` varchar(30) NOT NULL,
  `ZIP` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `adress`
--

INSERT INTO `adress` (`AdressID`, `Country`, `City`, `ZIP`) VALUES
(1, 'Romania', 'Timisoara', 23980),
(2, 'Austria', 'Vienna', 1100),
(3, 'Austria', 'Vienna', 1150),
(4, 'France', 'Paris', 5577),
(5, 'U.S.A.', 'Los Angeles', 4327),
(6, 'Romania', 'Oravita', 6790),
(7, 'Germany', 'Berlin', 8990),
(8, 'U.S.A.', 'Beverly Hills', 90210),
(9, 'Japan', 'Tokyo', 5465),
(10, 'Rusia', 'Moscow', 9099);

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `CompanyID` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Webseite` varchar(50) NOT NULL,
  `Telefon` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`CompanyID`, `Name`, `Webseite`, `Telefon`) VALUES
(1, 'NOKIA', 'www.nokia.com', '+43 676 00 00 999'),
(2, 'APPLE', 'www.apple.com', '+43 676 22 22 222'),
(3, 'Gucci', 'www.gucci.com', '+43 660 88 99 898'),
(4, 'Channel', 'www.chanel.com', '+43 660 66 77 888'),
(5, 'Loreal', 'www.loreal.com', '+43 676 11 22 333'),
(6, 'RedBull', 'www.redbull.com', '+43 676 44 55 666');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `OrdersID` int(11) NOT NULL,
  `fk_ShoppingCartID` int(11) NOT NULL,
  `Summe` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`OrdersID`, `fk_ShoppingCartID`, `Summe`) VALUES
(1, 1, '7300.00'),
(2, 2, '139.99'),
(3, 3, '5.49'),
(4, 4, '1.49'),
(5, 5, '79.99'),
(6, 6, '49.99'),
(7, 7, '5.49'),
(8, 8, '1299.99'),
(9, 9, '5.49'),
(10, 10, '49.99');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `PaymentID` int(11) NOT NULL,
  `PDate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `fk_PayTypeID` int(11) NOT NULL,
  `fk_OrderID` int(11) NOT NULL,
  `fk_UserID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`PaymentID`, `PDate`, `fk_PayTypeID`, `fk_OrderID`, `fk_UserID`) VALUES
(1, '1987-10-01 04:22:00', 1, 1, 1),
(2, '2021-03-31 23:23:00', 4, 2, 2),
(3, '2021-07-20 10:52:00', 2, 3, 3),
(4, '2021-09-30 13:45:00', 4, 4, 4),
(5, '2021-10-04 09:23:00', 3, 5, 5),
(6, '2021-07-02 15:50:00', 1, 6, 6),
(7, '2021-05-02 15:50:00', 2, 7, 7),
(8, '2021-02-26 15:34:00', 3, 8, 8),
(9, '2021-03-02 16:50:00', 4, 9, 9),
(10, '2021-03-06 18:50:00', 1, 10, 10);

-- --------------------------------------------------------

--
-- Table structure for table `paytype`
--

CREATE TABLE `paytype` (
  `PayTypeID` int(11) NOT NULL,
  `TName` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `paytype`
--

INSERT INTO `paytype` (`PayTypeID`, `TName`) VALUES
(1, 'PayPal'),
(2, 'Debit Card'),
(3, 'VISA'),
(4, 'Cash');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `ProductID` int(11) NOT NULL,
  `PName` varchar(30) NOT NULL,
  `PDescription` varchar(500) NOT NULL,
  `Price` decimal(8,2) DEFAULT NULL,
  `fk_CompanyID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`ProductID`, `PName`, `PDescription`, `Price`, `fk_CompanyID`) VALUES
(1, 'NOKIA 3310', 'The most longevive Telephone', '49.99', 1),
(2, 'NOKIA 7200', 'It\'s good to have it', '79.99', 1),
(3, 'RedBull 0,25 Dose', 'RedBull gives you Wings', '1.49', 6),
(4, 'Parfum Channel Madmoiselle', 'The Immortal Essence', '139.99', 4),
(5, 'Parfum Channel Coco', 'Sweet & Strong', '139.99', 4),
(6, 'Lipstick', 'Red', '5.49', 5),
(7, 'Lipstick', 'Pink', '5.49', 5),
(8, 'Iphone 13', 'The newest', '1299.99', 2),
(9, 'Gown', 'Made from lace', '7300.00', 3);

-- --------------------------------------------------------

--
-- Table structure for table `shipcompany`
--

CREATE TABLE `shipcompany` (
  `ShipCompanyID` int(11) NOT NULL,
  `SName` varchar(50) DEFAULT NULL,
  `Website` varchar(50) DEFAULT NULL,
  `Telefon` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `shipcompany`
--

INSERT INTO `shipcompany` (`ShipCompanyID`, `SName`, `Website`, `Telefon`) VALUES
(1, 'PRIME', 'www.prime.com', '+43 660 55 22 333'),
(2, 'TAXI', 'www.taxi.com', '+43 660 55 22 000'),
(3, 'Veloce', 'www.veloce.com', '+43 660 55 22 111'),
(4, 'Atlassib', 'www.atlassib.com', '+43 660 55 22 222');

-- --------------------------------------------------------

--
-- Table structure for table `shipping`
--

CREATE TABLE `shipping` (
  `ShippingID` int(11) NOT NULL,
  `SDate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `fk_PaymentID` int(11) NOT NULL,
  `fk_ShipCompanyID` int(11) NOT NULL,
  `fk_UserID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `shipping`
--

INSERT INTO `shipping` (`ShippingID`, `SDate`, `fk_PaymentID`, `fk_ShipCompanyID`, `fk_UserID`) VALUES
(1, '1987-10-02 04:22:00', 1, 1, 1),
(2, '2021-04-01 23:23:00', 2, 4, 2),
(3, '2021-07-21 10:52:00', 3, 2, 3),
(4, '2021-10-01 13:45:00', 4, 4, 4),
(5, '2021-10-05 09:23:00', 5, 3, 5),
(6, '2021-07-06 15:50:00', 6, 1, 6),
(7, '2021-05-03 15:50:00', 7, 2, 7),
(8, '2021-02-27 15:34:00', 8, 3, 8),
(9, '2021-03-03 16:50:00', 9, 4, 9),
(10, '2021-03-07 18:50:00', 10, 1, 10);

-- --------------------------------------------------------

--
-- Table structure for table `shoppingcart`
--

CREATE TABLE `shoppingcart` (
  `ShoppingCartID` int(11) NOT NULL,
  `fk_User_ProductID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `shoppingcart`
--

INSERT INTO `shoppingcart` (`ShoppingCartID`, `fk_User_ProductID`) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5),
(6, 6),
(7, 7),
(8, 8),
(9, 9),
(10, 10);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `UserID` int(11) NOT NULL,
  `FName` varchar(30) NOT NULL,
  `LName` varchar(30) NOT NULL,
  `UserName` varchar(35) DEFAULT NULL,
  `Email` varchar(30) DEFAULT NULL,
  `HouseStreet` varchar(50) DEFAULT NULL,
  `fk_AdressID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`UserID`, `FName`, `LName`, `UserName`, `Email`, `HouseStreet`, `fk_AdressID`) VALUES
(1, 'Laura', 'Moldovan', 'LauraM', 'laura.duduma@gmail.com', 'Andrei Saguna, 32', 6),
(2, 'Britney', 'Spears', 'Brit.S', 'britney@gmail.com', 'Heaven Street, 77/7', 5),
(3, 'Beyonce', 'Knowless', 'QueenB', 'beyonce@gmail.com', 'Champ d\'Elisee, 3/2/7', 4),
(4, 'Sebastian', 'Kurz', 'BastiK', 'seby.kurz@gmail.com', 'Neubaugürtel, 19/14', 3),
(5, 'Channing', 'Tatum', 'MagicMike', 'channing@gmail.com', 'Brenda & Brandon, 12/4', 8),
(6, 'Vladimir', 'Putin', 'VladP', 'vladimir@gmail.com', 'Kokoshnik, 33/3', 10),
(7, 'Jackye', 'Chan', 'KungFu', 'karate@gmail.com', 'Driffting Street, 8/2', 9),
(8, 'Jay', 'Z', 'Jay-Z', 'jay_z@gmail.com', 'Champ d\'Elisee, 3/2/1', 4),
(9, 'Dominic', 'Moldovan', 'DomM', 'domm@gmail.com', 'Andrei Saguna, 38', 6),
(10, 'Stana', 'Izbasa', 'SteauaR', 's.izbasa@gmail.com', 'Brancoveanu, 42/5/7', 1),
(11, 'Dragana', 'Mirkovic', 'DragaM', 'dm@gmail.com', 'Brunnweg, 4/10/8', 2),
(12, 'William', 'Shakespeare', 'WillyBoy', 'shakespeare@gmail.com', 'Burggasse, 22/3', 7);

-- --------------------------------------------------------

--
-- Table structure for table `user_product`
--

CREATE TABLE `user_product` (
  `User_ProductID` int(11) NOT NULL,
  `fk_UserID` int(11) NOT NULL,
  `fk_ProductID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_product`
--

INSERT INTO `user_product` (`User_ProductID`, `fk_UserID`, `fk_ProductID`) VALUES
(1, 1, 9),
(2, 2, 5),
(3, 3, 6),
(4, 4, 3),
(5, 5, 2),
(6, 6, 1),
(7, 7, 4),
(8, 8, 8),
(9, 9, 7),
(10, 10, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adress`
--
ALTER TABLE `adress`
  ADD PRIMARY KEY (`AdressID`);

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`CompanyID`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`OrdersID`),
  ADD KEY `fk_ShoppingCartID` (`fk_ShoppingCartID`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`PaymentID`),
  ADD KEY `fk_PayTypeID` (`fk_PayTypeID`),
  ADD KEY `fk_OrderID` (`fk_OrderID`),
  ADD KEY `fk_UserID` (`fk_UserID`);

--
-- Indexes for table `paytype`
--
ALTER TABLE `paytype`
  ADD PRIMARY KEY (`PayTypeID`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`ProductID`),
  ADD KEY `fk_CompanyID` (`fk_CompanyID`);

--
-- Indexes for table `shipcompany`
--
ALTER TABLE `shipcompany`
  ADD PRIMARY KEY (`ShipCompanyID`);

--
-- Indexes for table `shipping`
--
ALTER TABLE `shipping`
  ADD PRIMARY KEY (`ShippingID`),
  ADD KEY `fk_PaymentID` (`fk_PaymentID`),
  ADD KEY `fk_ShipCompanyID` (`fk_ShipCompanyID`),
  ADD KEY `fk_UserID` (`fk_UserID`);

--
-- Indexes for table `shoppingcart`
--
ALTER TABLE `shoppingcart`
  ADD PRIMARY KEY (`ShoppingCartID`),
  ADD KEY `fk_User_ProductID` (`fk_User_ProductID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`UserID`),
  ADD KEY `fk_AdressID` (`fk_AdressID`);

--
-- Indexes for table `user_product`
--
ALTER TABLE `user_product`
  ADD PRIMARY KEY (`User_ProductID`),
  ADD KEY `fk_UserID` (`fk_UserID`),
  ADD KEY `fk_ProductID` (`fk_ProductID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adress`
--
ALTER TABLE `adress`
  MODIFY `AdressID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `CompanyID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `OrdersID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `PaymentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `paytype`
--
ALTER TABLE `paytype`
  MODIFY `PayTypeID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `ProductID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `shipcompany`
--
ALTER TABLE `shipcompany`
  MODIFY `ShipCompanyID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `shipping`
--
ALTER TABLE `shipping`
  MODIFY `ShippingID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `shoppingcart`
--
ALTER TABLE `shoppingcart`
  MODIFY `ShoppingCartID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `user_product`
--
ALTER TABLE `user_product`
  MODIFY `User_ProductID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`fk_ShoppingCartID`) REFERENCES `shoppingcart` (`ShoppingCartID`) ON DELETE CASCADE;

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`fk_PayTypeID`) REFERENCES `paytype` (`PayTypeID`) ON DELETE CASCADE,
  ADD CONSTRAINT `payment_ibfk_2` FOREIGN KEY (`fk_OrderID`) REFERENCES `orders` (`OrdersID`) ON DELETE CASCADE,
  ADD CONSTRAINT `payment_ibfk_3` FOREIGN KEY (`fk_UserID`) REFERENCES `users` (`UserID`) ON DELETE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`fk_CompanyID`) REFERENCES `company` (`CompanyID`) ON DELETE CASCADE;

--
-- Constraints for table `shipping`
--
ALTER TABLE `shipping`
  ADD CONSTRAINT `shipping_ibfk_1` FOREIGN KEY (`fk_PaymentID`) REFERENCES `payment` (`PaymentID`) ON DELETE CASCADE,
  ADD CONSTRAINT `shipping_ibfk_2` FOREIGN KEY (`fk_ShipCompanyID`) REFERENCES `shipcompany` (`ShipCompanyID`) ON DELETE CASCADE,
  ADD CONSTRAINT `shipping_ibfk_3` FOREIGN KEY (`fk_UserID`) REFERENCES `users` (`UserID`) ON DELETE CASCADE;

--
-- Constraints for table `shoppingcart`
--
ALTER TABLE `shoppingcart`
  ADD CONSTRAINT `shoppingcart_ibfk_1` FOREIGN KEY (`fk_User_ProductID`) REFERENCES `user_product` (`User_ProductID`) ON DELETE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`fk_AdressID`) REFERENCES `adress` (`AdressID`) ON DELETE CASCADE;

--
-- Constraints for table `user_product`
--
ALTER TABLE `user_product`
  ADD CONSTRAINT `user_product_ibfk_1` FOREIGN KEY (`fk_UserID`) REFERENCES `users` (`UserID`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_product_ibfk_2` FOREIGN KEY (`fk_ProductID`) REFERENCES `products` (`ProductID`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
